//
//  main.m
//  IgnoreThisTarget
//
//  Created by Franklin Webber on 10/21/13.
//
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
