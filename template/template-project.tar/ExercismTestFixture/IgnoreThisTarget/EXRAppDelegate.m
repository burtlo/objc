//
//  EXRAppDelegate.m
//  IgnoreThisTarget
//
//  Created by Franklin Webber on 10/21/13.
//
//

#import "EXRAppDelegate.h"

@implementation EXRAppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
