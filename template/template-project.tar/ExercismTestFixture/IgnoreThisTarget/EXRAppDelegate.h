//
//  EXRAppDelegate.h
//  IgnoreThisTarget
//
//  Created by Franklin Webber on 10/21/13.
//
//

#import <Cocoa/Cocoa.h>

@interface EXRAppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
